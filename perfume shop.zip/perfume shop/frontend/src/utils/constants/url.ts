export const API_BASE_URL = "http://localhost:8080/api/v1";
export const WEBSOCKET_URL = "http://localhost:8080/websocket";
