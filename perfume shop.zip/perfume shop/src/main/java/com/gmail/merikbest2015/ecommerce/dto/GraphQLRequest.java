package com.gmail.naufalbest2022.ecommerce.dto;

import lombok.Data;

@Data
public class GraphQLRequest {
    private String query;
}
