package com.gmail.naufalbest2022.ecommerce.domain;

public enum Role {
    USER, ADMIN
}
