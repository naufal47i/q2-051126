package com.gmail.naufalbest2022.ecommerce.domain;

public enum AuthProvider {
    LOCAL, GOOGLE, GITHUB, FACEBOOK
}
