delete from orders_order_items;
delete from order_item;
delete from orders;
