delete from perfume_reviews;
delete from review;
delete from perfume;
