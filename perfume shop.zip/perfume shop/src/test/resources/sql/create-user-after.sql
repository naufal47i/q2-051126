delete from user_role;
delete from users;
